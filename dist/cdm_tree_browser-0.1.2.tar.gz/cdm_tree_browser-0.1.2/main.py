def main():
    print("Hello from cdm-tree-browser!")


if __name__ == "__main__":
    main()

"use strict";
(self["webpackChunkcdm_tree_browser"] = self["webpackChunkcdm_tree_browser"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tanstack/react-query */ "webpack/sharing/consume/default/@tanstack/react-query/@tanstack/react-query");
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_fontawesome_free_svgs_solid_boxes_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/fontawesome-free/svgs/solid/boxes.svg */ "./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg");
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-arborist */ "webpack/sharing/consume/default/react-arborist/react-arborist");
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_arborist__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/react-fontawesome */ "webpack/sharing/consume/default/@fortawesome/react-fontawesome/@fortawesome/react-fontawesome");
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "webpack/sharing/consume/default/@fortawesome/free-solid-svg-icons/@fortawesome/free-solid-svg-icons");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_8__);









/**
 * Initialization data for the cdm-tree-browser extension.
 */
const plugin = {
    id: 'cdm-tree-browser:plugin',
    description: 'A JupyterLab extension for browsing file/data trees in KBase CDM JupyterLab.',
    autoStart: true,
    activate: async (app) => {
        console.log('JupyterLab extension cdm-tree-browser is activated!');
        onActivate(app);
    },
    deactivate: () => {
        console.log('JupyterLab extension cdm-tree-browser was deactivated!');
    }
};
function onActivate(app) {
    const panel = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Panel();
    panel.id = 'cdm-tree-browser';
    panel.title.icon = {
        render: element => {
            element.innerHTML = _fortawesome_fontawesome_free_svgs_solid_boxes_svg__WEBPACK_IMPORTED_MODULE_4__;
            element.setAttribute('style', 'align-items: center; display: flex; flex: 0 0 auto;');
            element
                .getElementsByTagName('svg')[0]
                .setAttribute('style', 'display: block; height: auto; margin: 0 auto; width: 16px; fill: #616161;');
        }
    };
    panel.addWidget(new TreeBrowserWidget());
    app.shell.add(panel, 'left', { rank: 1 });
}
class TreeBrowserWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor() {
        super();
    }
    render() {
        // Extension React App setup (App.tsx equivalent)
        const queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient();
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClientProvider, { client: queryClient },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(TreeBrowser, null)));
    }
}
function TreeBrowser() {
    // For API calls we can use react-query (instead of rtk-query as redux is overkill)
    const query = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)({
        queryKey: ['namespaces'],
        queryFn: async () => 'someData'
    });
    const doAction = (id) => {
        console.log('action', id);
    };
    console.log('namespaces', query.status, query.data, query.error);
    const treeData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => {
        // perform any client-side transformations
        return [
            { id: '1', name: 'Empty', icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAnglesRight, children: [] },
            { id: '2', name: 'Empty 2', icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAnglesRight, children: [] },
            {
                id: '3',
                name: 'Some Data Source',
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAnglesRight,
                children: [
                    { id: 'c1', name: 'Data 1', onAction: doAction },
                    { id: 'c2', name: 'Data 2', onAction: doAction },
                    { id: 'c3', name: 'Data 3', onAction: doAction }
                ]
            },
            {
                id: '4',
                name: 'Another Data Source',
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAnglesRight,
                children: [
                    { id: 'd1', name: 'Alice', onAction: doAction },
                    { id: 'd2', name: 'Bob', onAction: doAction },
                    { id: 'd3', name: 'Charlie', onAction: doAction }
                ]
            }
        ]; // from query.data
    }, [query.data]);
    // For the tree we can use react-arborist
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Container, { className: "jp-TreeBrowserWidget", maxWidth: "sm" },
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(react_arborist__WEBPACK_IMPORTED_MODULE_5__.Tree, { initialData: treeData }, ({ node, style, dragHandle, tree }) => {
            return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { style: style, ref: dragHandle, onClick: !node.isLeaf ? () => { var _a; return (_a = tree.get(node.id)) === null || _a === void 0 ? void 0 : _a.toggle(); } : undefined },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Stack, { direction: 'row', spacing: 1, alignItems: 'center' },
                    !node.isLeaf ? (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_6__.FontAwesomeIcon, { fixedWidth: true, icon: node.isOpen ? _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAngleDown : _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faAngleRight })) : undefined,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_8__.Typography, { variant: "body1" }, node.data.name)),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", null, node.isLeaf ? (node.data.onAction ? (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_8__.IconButton, { size: 'small', onClick: () => { var _a, _b; return (_b = (_a = node.data).onAction) === null || _b === void 0 ? void 0 : _b.call(_a, node.id); } },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_6__.FontAwesomeIcon, { fontSize: 'inherit', fixedWidth: true, icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_7__.faRightToBracket }))) : undefined) : undefined))));
        })));
}
// https://github.com/jupyterlab/extension-examples/blob/main/kernel-messaging
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg":
/*!*************************************************************************!*\
  !*** ./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 576 512\"><!-- Font Awesome Free 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) --><path d=\"M560 288h-80v96l-32-21.3-32 21.3v-96h-80c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16h224c8.8 0 16-7.2 16-16V304c0-8.8-7.2-16-16-16zm-384-64h224c8.8 0 16-7.2 16-16V16c0-8.8-7.2-16-16-16h-80v96l-32-21.3L256 96V0h-80c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16zm64 64h-80v96l-32-21.3L96 384v-96H16c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16h224c8.8 0 16-7.2 16-16V304c0-8.8-7.2-16-16-16z\"/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.d660b211b47d09444b0d.js.map
"use strict";
(self["webpackChunkcdm_tree_browser"] = self["webpackChunkcdm_tree_browser"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tanstack/react-query */ "webpack/sharing/consume/default/@tanstack/react-query/@tanstack/react-query");
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_fontawesome_free_svgs_solid_boxes_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/fontawesome-free/svgs/solid/boxes.svg */ "./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg");
/* harmony import */ var _treeBrowser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./treeBrowser */ "./lib/treeBrowser.js");






/**
 * Initialization data for the cdm-tree-browser extension.
 */
const plugin = {
    id: 'cdm-tree-browser:plugin',
    description: 'A JupyterLab extension for browsing file/data trees in KBase CDM JupyterLab.',
    autoStart: true,
    activate: async (app) => {
        console.log('JupyterLab extension cdm-tree-browser is activated!');
        const panel = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Panel();
        panel.id = 'cdm-tree-browser';
        panel.title.icon = browserIcon;
        panel.addWidget(new TreeBrowserWidget(app));
        app.shell.add(panel, 'left', { rank: 1 });
    },
    deactivate: () => {
        console.log('JupyterLab extension cdm-tree-browser was deactivated!');
    }
};
class TreeBrowserWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(app) {
        super();
        this.app = app;
    }
    render() {
        // Extension React App setup (App.tsx equivalent)
        const queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient();
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClientProvider, { client: queryClient },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_treeBrowser__WEBPACK_IMPORTED_MODULE_5__.TreeBrowser, { jupyterApp: this.app })));
    }
}
const browserIcon = {
    render: host => {
        host.innerHTML = _fortawesome_fontawesome_free_svgs_solid_boxes_svg__WEBPACK_IMPORTED_MODULE_4__;
        host.setAttribute('style', 'align-items: center; display: flex; flex: 0 0 auto;');
        host
            .getElementsByTagName('svg')[0]
            .setAttribute('style', 'display: block; height: auto; margin: 0 auto; width: 16px; fill: #616161;');
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/kernelCommunication.js":
/*!************************************!*\
  !*** ./lib/kernelCommunication.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   queryKernel: () => (/* binding */ queryKernel),
/* harmony export */   useSessionContext: () => (/* binding */ useSessionContext)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
// Based on https://github.com/jupyterlab/extension-examples/blob/main/kernel-messaging


// Creates and initializes a sessionContext for use with a kernel
const useSessionContext = (app) => {
    const [sc, setSc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        const manager = app.serviceManager;
        const sessionContext = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.SessionContext({
            sessionManager: manager.sessions,
            specsManager: manager.kernelspecs,
            name: 'cdm-tree-browser'
        });
        void sessionContext
            .initialize()
            .then(async (value) => {
            if (value) {
                // const sessionContextDialogs = new SessionContextDialogs({});
                // await sessionContextDialogs.selectKernel(sessionContext); // Show kernel selection dialog
                await sessionContext.changeKernel({ name: 'python3' }); // skip dialog
                setSc(sessionContext);
            }
        })
            .catch(reason => {
            console.error(`Failed to initialize the session.\n${reason}`);
        });
        return () => {
            sessionContext.dispose();
            setSc(undefined);
        };
    }, [app.shell.id]);
    return sc;
};
// Executes a kernel query in a given sessionContext
const queryKernel = async (code, sessionContext) => {
    var _a;
    const kernel = (_a = sessionContext === null || sessionContext === void 0 ? void 0 : sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
    if (!kernel) {
        throw new Error('kernel DNE');
    }
    const future = kernel.requestExecute({ code });
    const output = await new Promise(resolve => {
        future.onIOPub = (msg) => {
            const msgType = msg.header.msg_type;
            switch (msgType) {
                case 'execute_result':
                case 'display_data':
                case 'update_display_data':
                    resolve(msg.content);
                    break;
                default:
                    break;
            }
        };
    });
    future.dispose();
    return output;
};


/***/ }),

/***/ "./lib/treeBrowser.js":
/*!****************************!*\
  !*** ./lib/treeBrowser.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TreeBrowser: () => (/* binding */ TreeBrowser)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tanstack/react-query */ "webpack/sharing/consume/default/@tanstack/react-query/@tanstack/react-query");
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-arborist */ "webpack/sharing/consume/default/react-arborist/react-arborist");
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_arborist__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fortawesome/react-fontawesome */ "webpack/sharing/consume/default/@fortawesome/react-fontawesome/@fortawesome/react-fontawesome");
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "webpack/sharing/consume/default/@fortawesome/free-solid-svg-icons/@fortawesome/free-solid-svg-icons");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _kernelCommunication__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./kernelCommunication */ "./lib/kernelCommunication.js");







const TreeBrowser = ({ jupyterApp }) => {
    const sessionContext = (0,_kernelCommunication__WEBPACK_IMPORTED_MODULE_6__.useSessionContext)(jupyterApp);
    // For API calls we can use react-query (instead of rtk-query as redux is overkill)
    const query = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)({
        queryKey: ['namespaces'],
        enabled: !!sessionContext && jupyterApp.serviceManager.isReady,
        queryFn: () => (0,_kernelCommunication__WEBPACK_IMPORTED_MODULE_6__.queryKernel)("import json\njson.dumps(['alexey', 'alexeyranjan', 'alexeyv8', 'credit_engine', 'default', 'enigma', 'fastgenomics', 'filipedb', 'gazi_db', 'img', 'janaka_db', 'modelseed_biochemistry', 'ontology_data', 'pangenome_ke', 'ranjandb', 'scarecrow_db', 'semsql', 'test'])", sessionContext),
        select: (data) => {
            if (data.data &&
                typeof data.data === 'object' &&
                'text/plain' in data.data) {
                return JSON.parse(data.data['text/plain'].replace(/^'|'$/g, '')).map((name, i) => ({
                    id: i.toString(),
                    name: name,
                    children: [
                        { id: `${i}.a`, name: 'Data 1', onAction: doAction },
                        { id: `${i}.b`, name: 'Data 2', onAction: doAction },
                        { id: `${i}.c`, name: 'Data 3', onAction: doAction }
                    ]
                }));
            }
            return [];
        }
    });
    const doAction = (id) => {
        console.log('action', id);
    };
    // For the tree we can use react-arborist (MIT)
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Container, { className: "jp-TreeBrowserWidget", maxWidth: "sm" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_arborist__WEBPACK_IMPORTED_MODULE_2__.Tree, { data: query.data || [] }, ({ node, style, dragHandle, tree }) => {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: style, ref: dragHandle, onClick: !node.isLeaf ? () => { var _a; return (_a = tree.get(node.id)) === null || _a === void 0 ? void 0 : _a.toggle(); } : undefined },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Stack, { direction: 'row', spacing: 1, alignItems: 'center' },
                    !node.isLeaf ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, { fixedWidth: true, icon: node.isOpen ? _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faAngleDown : _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faAngleRight })) : undefined,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, { variant: "body1" }, node.data.name)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, node.isLeaf ? (node.data.onAction ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, { size: 'small', onClick: () => { var _a, _b; return (_b = (_a = node.data).onAction) === null || _b === void 0 ? void 0 : _b.call(_a, node.id); } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, { fontSize: 'inherit', fixedWidth: true, icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faRightToBracket }))) : undefined) : undefined))));
        })));
};


/***/ }),

/***/ "./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg":
/*!*************************************************************************!*\
  !*** ./node_modules/@fortawesome/fontawesome-free/svgs/solid/boxes.svg ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 576 512\"><!-- Font Awesome Free 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) --><path d=\"M560 288h-80v96l-32-21.3-32 21.3v-96h-80c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16h224c8.8 0 16-7.2 16-16V304c0-8.8-7.2-16-16-16zm-384-64h224c8.8 0 16-7.2 16-16V16c0-8.8-7.2-16-16-16h-80v96l-32-21.3L256 96V0h-80c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16zm64 64h-80v96l-32-21.3L96 384v-96H16c-8.8 0-16 7.2-16 16v192c0 8.8 7.2 16 16 16h224c8.8 0 16-7.2 16-16V304c0-8.8-7.2-16-16-16z\"/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.71adbf17e303b9ea286f.js.map
def main():
    print("Hello from cdm-schema-browser!")


if __name__ == "__main__":
    main()
